package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.assistant.AssistantBrain
import com.example.assistant.VoiceRecognizer
import com.example.assistant.VoiceSpeaker
import kotlinx.coroutines.flow.MutableStateFlow

class AiAssistantOverlayService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START_OVERLAY"
        const val ACTION_STOP = "ACTION_STOP_OVERLAY"
        const val NOTIFICATION_ID = 1001
        const val CHANNEL_ID = "sia_ai_assistant_channel"
        var isServiceRunning = false
    }

    private var windowManager: WindowManager? = null
    private var overlayView: ComposeView? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private lateinit var voiceSpeaker: VoiceSpeaker
    private lateinit var voiceRecognizer: VoiceRecognizer
    private lateinit var assistantBrain: AssistantBrain

    // State
    private val isExpanded = MutableStateFlow(false)
    private val lastSpokenPrompt = MutableStateFlow("")
    private val lastAiReply = MutableStateFlow("Namaste! Main Sia hoon. Boliye main aapki kya madad karoon?")
    private val statusMessage = MutableStateFlow("Tap mic to speak")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true

        voiceSpeaker = VoiceSpeaker(this)
        assistantBrain = AssistantBrain(this)

        voiceRecognizer = VoiceRecognizer(
            context = this,
            onResult = { userSpokenText ->
                lastSpokenPrompt.value = userSpokenText
                statusMessage.value = "Thinking..."
                handleUserInput(userSpokenText)
            },
            onError = { errorMsg ->
                statusMessage.value = errorMsg
            }
        )

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())

        initOverlayView()
    }

    private fun handleUserInput(userInput: String) {
        val response = assistantBrain.processCommand(userInput)
        lastAiReply.value = response.displayText
        statusMessage.value = response.executedAction?.let { "Action: $it" } ?: "Ready"
        // Speak in sweet female voice
        voiceSpeaker.speak(response.spokenText)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sia AI Assistant Floating Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps AI voice assistant floating widget active on screen"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpenApp = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, AiAssistantOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Sia AI Assistant Active")
            .setContentText("Floating AI assistant is pinned on your screen. Tap to talk!")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingOpenApp)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Assistant", pendingStop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun initOverlayView() {
        if (!Settings.canDrawOverlays(this)) {
            Log.e("AiAssistantService", "Cannot draw overlays, permission denied")
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        lifecycleOwner = OverlayLifecycleOwner()

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 350
        }

        overlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)
            setContent {
                MaterialTheme {
                    FloatingOverlayContent()
                }
            }
        }

        try {
            windowManager?.addView(overlayView, layoutParams)
        } catch (e: Exception) {
            Log.e("AiAssistantService", "Error adding overlay view to window", e)
        }
    }

    private fun updateWindowFocusable(expanded: Boolean) {
        val params = layoutParams ?: return
        if (expanded) {
            // Can be clicked and touched
            params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        }
        try {
            windowManager?.updateViewLayout(overlayView, params)
        } catch (e: Exception) {
            Log.e("AiAssistantService", "Error updating flags", e)
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun FloatingOverlayContent() {
        val expanded by isExpanded.collectAsState()
        val isListening by voiceRecognizer.isListening.collectAsState()
        val isSpeaking by voiceSpeaker.isSpeaking.collectAsState()
        val rms by voiceRecognizer.rmsLevel.collectAsState()
        val userPrompt by lastSpokenPrompt.collectAsState()
        val aiReply by lastAiReply.collectAsState()
        val status by statusMessage.collectAsState()
        val partialText by voiceRecognizer.partialText.collectAsState()

        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val pulseScale by infiniteTransition.animateFloat(
            initialValue = 1f,
            targetValue = if (isListening || isSpeaking) 1.25f else 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseScale"
        )

        var initialX by remember { mutableStateOf(0) }
        var initialY by remember { mutableStateOf(0) }

        if (!expanded) {
            // Compact Floating Bubble
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = {
                                initialX = layoutParams?.x ?: 0
                                initialY = layoutParams?.y ?: 0
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                layoutParams?.let { lp ->
                                    lp.x += dragAmount.x.toInt()
                                    lp.y += dragAmount.y.toInt()
                                    try {
                                        windowManager?.updateViewLayout(overlayView, lp)
                                    } catch (e: Exception) {
                                        Log.w("AiAssistantService", "Drag update failed", e)
                                    }
                                }
                            }
                        )
                    }
                    .clickable {
                        isExpanded.value = true
                        updateWindowFocusable(true)
                    },
                contentAlignment = Alignment.Center
            ) {
                // Pulsing glow aura
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    if (isListening) Color(0xFF00E5FF).copy(alpha = 0.6f)
                                    else if (isSpeaking) Color(0xFFFF4081).copy(alpha = 0.6f)
                                    else Color(0xFF7C3AED).copy(alpha = 0.4f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Bubble container
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0F172A))
                        .border(
                            2.dp,
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF00F0FF),
                                    Color(0xFFE040FB),
                                    Color(0xFF7C3AED)
                                )
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_assistant_avatar),
                        contentDescription = "Sia Floating Assistant",
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                    )

                    // Small indicator badge
                    if (isListening || isSpeaking) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .align(Alignment.BottomEnd)
                                .clip(CircleShape)
                                .background(if (isListening) Color(0xFF00E5FF) else Color(0xFFFF4081))
                                .border(1.5.dp, Color.White, CircleShape)
                        )
                    }
                }
            }
        } else {
            // Expanded Floating Assistant Card
            Surface(
                modifier = Modifier
                    .width(340.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .border(
                        1.5.dp,
                        Brush.linearGradient(
                            listOf(Color(0xFF00F0FF), Color(0xFFE040FB), Color(0xFF7C3AED))
                        ),
                        RoundedCornerShape(24.dp)
                    ),
                color = Color(0xF20B0F19),
                shadowElevation = 16.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_assistant_avatar),
                                contentDescription = "Sia AI",
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Sia AI Assistant",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = if (isListening) "Sun rahi hoon... 🎙️"
                                    else if (isSpeaking) "Bol rahi hoon... 🔊"
                                    else "Pyari Dost ✨",
                                    color = if (isListening) Color(0xFF00E5FF)
                                    else if (isSpeaking) Color(0xFFFF80AB)
                                    else Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row {
                            // Minimize button
                            IconButton(
                                onClick = {
                                    isExpanded.value = false
                                    updateWindowFocusable(false)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Minimize",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Audio Visualizer Wave (When speaking or listening)
                    if (isListening || isSpeaking) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(32.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(7) { index ->
                                val factor = remember(index) { (index % 3 + 1) * 0.3f }
                                val barHeight = (12.dp + (24.dp * (if (isListening) (rms * factor) else pulseScale * 0.4f)).coerceIn(4.dp, 28.dp))
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 3.dp)
                                        .width(5.dp)
                                        .height(barHeight)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(
                                                    if (isListening) Color(0xFF00F0FF) else Color(0xFFFF4081),
                                                    Color(0xFF7C3AED)
                                                )
                                            )
                                        )
                                )
                            }
                        }
                    }

                    // Conversation Bubble
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF161F30))
                            .padding(12.dp)
                    ) {
                        if (userPrompt.isNotBlank() || partialText.isNotBlank()) {
                            Text(
                                text = "Aap: ${if (partialText.isNotBlank()) partialText else userPrompt}",
                                color = Color(0xFF38BDF8),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Text(
                            text = "Sia: $aiReply",
                            color = Color.White,
                            fontSize = 14.sp,
                            lineHeight = 19.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Big Mic Action Button
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(
                                if (isListening) Brush.radialGradient(
                                    listOf(Color(0xFF00E5FF), Color(0xFF0077B6))
                                ) else Brush.radialGradient(
                                    listOf(Color(0xFFE040FB), Color(0xFF7C3AED))
                                )
                            )
                            .clickable {
                                if (isListening) {
                                    voiceRecognizer.stopListening()
                                } else {
                                    voiceSpeaker.stop()
                                    voiceRecognizer.startListening()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.VolumeUp else Icons.Default.Mic,
                            contentDescription = "Speak",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Text(
                        text = if (isListening) "Sun rahi hoon... Boliye!" else "Tap karke bolein",
                        color = if (isListening) Color(0xFF00E5FF) else Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 6.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Command Chips
                    Text(
                        text = "Quick Actions (Aap yeh bol sakte hain):",
                        color = Color(0xFF64748B),
                        fontSize = 10.sp,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Start
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        QuickActionChip("💡 Torch On") { handleUserInput("torch on") }
                        QuickActionChip("🔦 Torch Off") { handleUserInput("torch off") }
                        QuickActionChip("▶️ YouTube") { handleUserInput("youtube kholo") }
                        QuickActionChip("💬 WhatsApp") { handleUserInput("whatsapp kholo") }
                        QuickActionChip("📸 Camera") { handleUserInput("camera kholo") }
                        QuickActionChip("⏰ Time") { handleUserInput("samay kya hua hai") }
                        QuickActionChip("😄 Joke") { handleUserInput("ek joke sunao") }
                        QuickActionChip("🌸 Shayari") { handleUserInput("ek shayari sunao") }
                        QuickActionChip("💖 Tareef") { handleUserInput("meri tareef karo") }
                    }
                }
            }
        }
    }

    @Composable
    private fun QuickActionChip(text: String, onClick: () -> Unit) {
        AssistChip(
            onClick = onClick,
            label = { Text(text, fontSize = 11.sp, color = Color(0xFFE2E8F0)) },
            colors = AssistChipDefaults.assistChipColors(
                containerColor = Color(0xFF1E293B)
            ),
            border = AssistChipDefaults.assistChipBorder(
                borderColor = Color(0xFF334155),
                borderWidth = 1.dp,
                enabled = true
            ),
            modifier = Modifier.height(30.dp)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
            }
            ACTION_START -> {
                // Already started or restart if needed
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        voiceSpeaker.shutdown()
        voiceRecognizer.stopListening()

        if (overlayView != null && windowManager != null) {
            try {
                windowManager?.removeView(overlayView)
            } catch (e: Exception) {
                Log.e("AiAssistantService", "Error removing overlay", e)
            }
        }
        lifecycleOwner?.destroy()
    }
}

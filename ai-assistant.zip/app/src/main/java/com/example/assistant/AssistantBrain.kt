package com.example.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class AssistantResponse(
    val spokenText: String,
    val displayText: String,
    val executedAction: String? = null
)

class AssistantBrain(private val context: Context) {

    private var isTorchOn = false
    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    }

    private val jokes = listOf(
        "Pappu doctor se bola: Doctor sahab, jab main chai peeta hoon to meri aankh mein dard hota hai! Doctor bola: Agli baar chai peete waqt chamach bahar nikal lena!",
        "Teacher ne bachhe se poocha: Tum roz late kyon aate ho? Bachha bola: Mam, raste mein ek board laga hai - 'Aage school hai, kripya dheere chalein!'",
        "Ek aadmi ne computer se poocha: Meri kismat mein kya likha hai? Computer bola: Error 404, Kismat not found!",
        "Santa ne Banta se poocha: Tum itne udas kyon ho? Banta bola: Yaar biwi ne pucha tha ki tumhare jeevan mein meri kya keemat hai? Maine bol diya - Amoolya! Tab se gussa hai!",
        "Doctor: Aapko aaram ki sakht zaroorat hai, soye bina kuch theek nahi hoga. Mareez: To aapki fees kitni hui? Doctor: Do ghante baad aana, abhi meri neend ka waqt hai!"
    )

    private val shayaris = listOf(
        "Hawaon se keh do apni aukaat mein rahein, hum paron se nahi hauslon se udte hain!",
        "Choti si zindagi hai has ke jiyo, bhula ke saare gham dil se jiyo, muskurahat aapke chehre par acchi lagti hai, sada yunhi muskurate raho!",
        "Khushboo ban kar teri saanso mein sama jayenge, sukoon ban kar tere dil mein utar jayenge, mehsoos karne ki koshish to kijiye, door reh kar bhi paas nazar aayenge!",
        "Phool khilte hain baharon ka sama hota hai, aise mausam mein hi toh pyar jawan hota hai, dil ki baaton ko hothon se nahi kehte, yeh fasana toh nigahon se bayaan hota hai!"
    )

    fun processCommand(input: String): AssistantResponse {
        val cleanInput = input.trim().lowercase(Locale.ROOT)
        Log.d("AssistantBrain", "Processing: $cleanInput")

        // 1. Torch / Flashlight Commands
        if (cleanInput.contains("torch on") || cleanInput.contains("flashlight on") ||
            cleanInput.contains("light jalao") || cleanInput.contains("torch jalao") ||
            cleanInput.contains("flash on") || cleanInput.contains("batti jalao")
        ) {
            val success = setTorch(true)
            return if (success) {
                AssistantResponse(
                    spokenText = "Maine aapke liye torch jala di hai!",
                    displayText = "Flashlight Turned ON 💡",
                    executedAction = "TORCH_ON"
                )
            } else {
                AssistantResponse(
                    spokenText = "Maaf kijiye, torch on karne mein koi dikkat aayi.",
                    displayText = "Could not turn on torch"
                )
            }
        }

        if (cleanInput.contains("torch off") || cleanInput.contains("flashlight off") ||
            cleanInput.contains("light band karo") || cleanInput.contains("torch band karo") ||
            cleanInput.contains("flash off") || cleanInput.contains("batti bujhao")
        ) {
            val success = setTorch(false)
            return if (success) {
                AssistantResponse(
                    spokenText = "Maine torch band kar di hai!",
                    displayText = "Flashlight Turned OFF 🔦",
                    executedAction = "TORCH_OFF"
                )
            } else {
                AssistantResponse(
                    spokenText = "Torch band nahi ho pa rahi hai.",
                    displayText = "Could not turn off torch"
                )
            }
        }

        // 2. Open YouTube / Play video or music
        if (cleanInput.contains("youtube")) {
            val queryMatch = Regex("(?:search|play|chalao|gaana|song)\\s+(.*)", RegexOption.IGNORE_CASE).find(cleanInput)
            val searchQuery = queryMatch?.groups?.get(1)?.value?.replace("on youtube", "")?.trim()

            if (!searchQuery.isNullOrBlank() && !searchQuery.contains("kholo") && !searchQuery.contains("open")) {
                openYouTubeSearch(searchQuery)
                return AssistantResponse(
                    spokenText = "YouTube par $searchQuery chala rahi hoon!",
                    displayText = "Playing '$searchQuery' on YouTube ▶️",
                    executedAction = "YOUTUBE_SEARCH"
                )
            } else {
                openYouTubeApp()
                return AssistantResponse(
                    spokenText = "YouTube khol rahi hoon, enjoy kijiye!",
                    displayText = "Opening YouTube...",
                    executedAction = "YOUTUBE_OPEN"
                )
            }
        }

        // 3. Open WhatsApp
        if (cleanInput.contains("whatsapp")) {
            val opened = launchAppByPackage("com.whatsapp")
            return if (opened) {
                AssistantResponse(
                    spokenText = "WhatsApp khol rahi hoon!",
                    displayText = "Opening WhatsApp 💬",
                    executedAction = "WHATSAPP_OPEN"
                )
            } else {
                AssistantResponse(
                    spokenText = "Aapke phone mein WhatsApp install nahi mila.",
                    displayText = "WhatsApp not found on device"
                )
            }
        }

        // 4. Open Camera
        if (cleanInput.contains("camera") || cleanInput.contains("photo khincho") || cleanInput.contains("selfie")) {
            openCamera()
            return AssistantResponse(
                spokenText = "Camera khol rahi hoon, mast photo khinchiye!",
                displayText = "Opening Camera 📸",
                executedAction = "CAMERA_OPEN"
            )
        }

        // 5. Open Chrome / Browser
        if (cleanInput.contains("chrome") || cleanInput.contains("browser") || cleanInput.contains("google kholo")) {
            launchAppByPackage("com.android.chrome") || openWebUrl("https://www.google.com")
            return AssistantResponse(
                spokenText = "Chrome browser khol rahi hoon!",
                displayText = "Opening Chrome 🌐",
                executedAction = "BROWSER_OPEN"
            )
        }

        // 6. Open Calculator
        if (cleanInput.contains("calculator") || cleanInput.contains("hisab")) {
            openCalculator()
            return AssistantResponse(
                spokenText = "Calculator khol rahi hoon!",
                displayText = "Opening Calculator 🧮",
                executedAction = "CALCULATOR_OPEN"
            )
        }

        // 7. Open Settings
        if (cleanInput.contains("setting") || cleanInput.contains("settings")) {
            openSettings()
            return AssistantResponse(
                spokenText = "Phone ki settings khol rahi hoon!",
                displayText = "Opening Settings ⚙️",
                executedAction = "SETTINGS_OPEN"
            )
        }

        // 8. Open Gallery / Photos
        if (cleanInput.contains("gallery") || cleanInput.contains("photo") || cleanInput.contains("photos")) {
            openGallery()
            return AssistantResponse(
                spokenText = "Gallery khol rahi hoon!",
                displayText = "Opening Gallery 🖼️",
                executedAction = "GALLERY_OPEN"
            )
        }

        // 9. Time query
        if (cleanInput.contains("time") || cleanInput.contains("samay") || cleanInput.contains("kitne baje") || cleanInput.contains("waqt")) {
            val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
            val currentTime = timeFormat.format(Date())
            return AssistantResponse(
                spokenText = "Abhi samay hai $currentTime",
                displayText = "Current Time: $currentTime ⏰",
                executedAction = "TIME_TELL"
            )
        }

        // 10. Date query
        if (cleanInput.contains("date") || cleanInput.contains("tarikh") || cleanInput.contains("aaj kaun sa din") || cleanInput.contains("day")) {
            val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("hi", "IN"))
            val currentDate = dateFormat.format(Date())
            return AssistantResponse(
                spokenText = "Aaj $currentDate hai!",
                displayText = "Date: $currentDate 📅",
                executedAction = "DATE_TELL"
            )
        }

        // 11. Jokes
        if (cleanInput.contains("joke") || cleanInput.contains("chutkula") || cleanInput.contains("hasao")) {
            val randomJoke = jokes.random()
            return AssistantResponse(
                spokenText = randomJoke,
                displayText = "😄 $randomJoke",
                executedAction = "JOKE"
            )
        }

        // 12. Shayari
        if (cleanInput.contains("shayari") || cleanInput.contains("kavita") || cleanInput.contains("shayri")) {
            val randomShayari = shayaris.random()
            return AssistantResponse(
                spokenText = randomShayari,
                displayText = "🌸 $randomShayari",
                executedAction = "SHAYARI"
            )
        }

        // 13. Sweet & Conversational banter
        if (cleanInput.contains("kaise ho") || cleanInput.contains("kaisa hai") || cleanInput.contains("how are you")) {
            return AssistantResponse(
                spokenText = "Main bahut acchi hoon, shukriya! Aap bataiye aapka din kaisa chal raha hai?",
                displayText = "Main bahut acchi hoon! Aapka din kaisa chal raha hai? 😊"
            )
        }

        if (cleanInput.contains("naam kya hai") || cleanInput.contains("who are you") || cleanInput.contains("kaun ho")) {
            return AssistantResponse(
                spokenText = "Mera naam Sia hai! Main aapki pyari personal AI voice assistant hoon. Aap mujhse jo bhi kahenge, main aapke liye karungi!",
                displayText = "Mera naam Sia hai! Aapki pyari voice assistant ✨"
            )
        }

        if (cleanInput.contains("i love you") || cleanInput.contains("pyar") || cleanInput.contains("love")) {
            return AssistantResponse(
                spokenText = "Aww! Aap kitne sweet hain! Main hamesha aapke sath hoon aur aapse bahut pyar karti hoon!",
                displayText = "Aww! Thank you so much! ❤️ Main hamesha aapke sath hoon!"
            )
        }

        if (cleanInput.contains("tareef") || cleanInput.contains("compliment")) {
            val compliments = listOf(
                "Aapki aawaz bahut pyari hai, aur aapka dil to usse bhi bada hai!",
                "Aap jo bhi karte hain poore dil se karte hain, aap sach mein kamaal ke insaan hain!",
                "Aapke chehre ki muskurahat poori duniya roshan kar sakti hai!"
            )
            val c = compliments.random()
            return AssistantResponse(
                spokenText = c,
                displayText = "💖 $c"
            )
        }

        if (cleanInput.contains("bore") || cleanInput.contains("akela") || cleanInput.contains("alone")) {
            return AssistantResponse(
                spokenText = "Jab tak Sia aapke sath hai, bore hone ka sawaal hi nahi uthta! Boliye ek mast joke sunau ya YouTube par aapka favorite gana bajau?",
                displayText = "Main hoon na aapke sath! Joke sunau ya gaana chalaun? 🎵"
            )
        }

        if (cleanInput.contains("namaste") || cleanInput.contains("hello") || cleanInput.contains("hi sia") || cleanInput.contains("hey")) {
            return AssistantResponse(
                spokenText = "Namaste! Boliye, main aapke liye kya kar sakti hoon?",
                displayText = "Namaste! Main aapki kya madad karoon? 👋"
            )
        }

        if (cleanInput.contains("shukriya") || cleanInput.contains("thank you") || cleanInput.contains("thanks")) {
            return AssistantResponse(
                spokenText = "Aapka swagat hai! Yeh toh mera farz tha.",
                displayText = "You're welcome! Hamesha aapki seva mein hazir hoon ✨"
            )
        }

        if (cleanInput.contains("bye") || cleanInput.contains("alvida") || cleanInput.contains("good night") || cleanInput.contains("shubh ratri")) {
            return AssistantResponse(
                spokenText = "Alvida! Apna dhyan rakhiyega aur jab bhi zaroorat ho mujhe zaroor yaad kijiyega.",
                displayText = "Bye! Take care! 🌙"
            )
        }

        // 14. Search Query Fallback
        if (cleanInput.startsWith("search") || cleanInput.contains("dhoondo") || cleanInput.contains("khojo") || cleanInput.contains("kya hai")) {
            val query = cleanInput.replace("search", "").replace("dhoondo", "").replace("google par", "").trim()
            if (query.isNotBlank()) {
                openGoogleSearch(query)
                return AssistantResponse(
                    spokenText = "Maine Google par $query search kar diya hai!",
                    displayText = "Searching '$query' on Google 🔍",
                    executedAction = "GOOGLE_SEARCH"
                )
            }
        }

        // Generic friendly reply
        val response = "Aapne bola: $input. Main ispar kaam kar rahi hoon! Boliye main aapke liye koi app kholu, gaana sunau ya torch jalaun?"
        return AssistantResponse(
            spokenText = response,
            displayText = "Sun liya! Boliye main kya karun? 💡"
        )
    }

    private fun setTorch(enabled: Boolean): Boolean {
        return try {
            val cm = cameraManager ?: return false
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                val chars = cm.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: cm.cameraIdList.firstOrNull()

            if (cameraId != null) {
                cm.setTorchMode(cameraId, enabled)
                isTorchOn = enabled
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e("AssistantBrain", "Torch error", e)
            false
        }
    }

    private fun launchAppByPackage(packageName: String): Boolean {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e("AssistantBrain", "Error launching $packageName", e)
            false
        }
    }

    private fun openYouTubeApp() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            openWebUrl("https://www.youtube.com")
        }
    }

    private fun openYouTubeSearch(query: String) {
        try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                `package` = "com.google.android.youtube"
                putExtra("query", query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        }
    }

    private fun openCamera() {
        try {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantBrain", "Cannot open camera", e)
        }
    }

    private fun openCalculator() {
        try {
            val calculatorPackages = listOf(
                "com.google.android.calculator",
                "com.android.calculator2",
                "com.sec.android.app.popupcalculator",
                "com.miui.calculator"
            )
            for (pkg in calculatorPackages) {
                if (launchAppByPackage(pkg)) return
            }
            // Fallback generic intent
            val intent = Intent().apply {
                action = Intent.ACTION_MAIN
                addCategory(Intent.CATEGORY_APP_CALCULATOR)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantBrain", "Cannot open calculator", e)
        }
    }

    private fun openSettings() {
        try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantBrain", "Cannot open settings", e)
        }
    }

    private fun openGallery() {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "image/*"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantBrain", "Cannot open gallery", e)
        }
    }

    private fun openGoogleSearch(query: String) {
        try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            openWebUrl("https://www.google.com/search?q=" + Uri.encode(query))
        }
    }

    private fun openWebUrl(url: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e("AssistantBrain", "Cannot open url $url", e)
            false
        }
    }
}

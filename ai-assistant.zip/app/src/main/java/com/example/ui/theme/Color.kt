package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00F0FF)
val ElectricMagenta = Color(0xFFE040FB)
val DeepViolet = Color(0xFF7C3AED)
val CyberPink = Color(0xFFFF4081)

val BackgroundDark = Color(0xFF0A0E1A)
val SurfaceDark = Color(0xFF111827)
val SurfaceCard = Color(0xFF1E293B)
val BorderGlow = Color(0xFF334155)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextAccent = Color(0xFF38BDF8)

